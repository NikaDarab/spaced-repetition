import React, { Component } from 'react'

class DashboardRoute extends Component {
  render() {
    return (
      <section>
        implement and style me
      </section>
    );
  }
}

export default DashboardRoute
