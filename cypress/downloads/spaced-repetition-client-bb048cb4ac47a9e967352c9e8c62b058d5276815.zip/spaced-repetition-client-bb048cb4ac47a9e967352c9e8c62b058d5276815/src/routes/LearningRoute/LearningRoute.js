import React, { Component } from 'react'

class LearningRoute extends Component {
  render() {
    return (
      <section>
        implement and style me
      </section>
    );
  }
}

export default LearningRoute
